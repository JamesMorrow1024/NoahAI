import Home from './views/home'

function App() {

  return (
    <>
      <Home />
    </>
  )
}

export default App
