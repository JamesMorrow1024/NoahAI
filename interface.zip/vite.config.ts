import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
// import AutoImport from "unplugin-auto-import/vite"
import ReactivityTransform from "@vue-macros/reactivity-transform/vite"
import path from "path"
// import '@dbfu/react-directive'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react({
      jsxImportSource: '@dbfu/react-directive'
    }),
    ReactivityTransform(), //  $ref ...
   
    // AutoImport({
    //   imports: ["react", "react-dom", "react-router-dom"],
    // }),
  ],
  base: './',
  resolve: {
    alias:{
      "@":path.resolve(__dirname,"./src")
    }
  },
  // 引入scss全局变量
  // css: {
  //   preprocessorOptions: {
  //     scss: {
  //       additionalData: `@import "@/styles/index.scss";`,
  //     },
  //   },
  // },
})
