

import React, { useState } from 'react';
// import { Upload, Button, Table } from 'antd';
import { trace } from '../../utils/tools';
import {  Button, Table } from 'antd';
import Papa from 'papaparse';


function Home(){
   
    const [csvData, setCsvData] = useState([]);
    const [calculateData, setCalculateData] = useState('Calculated  fee');
    const [selectedRowKeys, setSelectedRowKeys] = useState([]);
    const [curRecord, setCurRecord] = useState({} as any);
    const onSelect = (record, selected, selectedRows) => {
        trace('record',record);
        setCurRecord(record);
        setSelectedRowKeys([record.node]);
    };
    const rowSelection = {
        type: 'radio',
        onSelect: onSelect,
        selectedRowKeys: selectedRowKeys,
      };
    

    const handleFileUpload = (e:any) => {
        const file = e.target.files[0];

        Papa.parse(file, {
        complete: (results:any) => {
            // trace('results',results);
            setCsvData(results.data);
        },
        header: true,
        });
    };

    const columns = [
        {
        title: 'Node',
        dataIndex: 'node',
        key: 'node',
        },
        {
        title: 'S',
        dataIndex: 's',
        key: 's',
        },
        {
        title: 'R',
        dataIndex: 'r',
        key: 'r',
        },
        {
        title: 'W',
        dataIndex: 'w',
        key: 'w',
        },
        {
        title: 'X',
        dataIndex: 'x',
        key: 'x',
        },
    ];

    async function calculate(){
        trace('selectedRowKeys',selectedRowKeys,curRecord);
        if(selectedRowKeys.length==0){
            return;
        }
        setCalculateData();

        let res = await postData({predict: [curRecord.node,curRecord.s,curRecord.r,curRecord.w,curRecord.x]});
        trace('res',res);

        if(res){
            setCalculateData(res.toString());
        }
    }

    function getKey(record:any){
        return record.node;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const postData = async (payload: any) => {
        try {
          const response = await fetch('http://localhost:5000/predict', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
          });
      
          if (!response.ok) {
            throw new Error('error');
          }
      
          const data = await response.json();
          return data;
        } catch (error) {
          console.error(error);
          return null;
        }
      };
   
    return(
        <div style={{display:'flex',padding:'48px'}}>
            <div style={{flex:'1'}}>

                <div >
                    <label htmlFor="csvFileInput" style={{position:'relative',color:'black',display:"inline-block"}}>
                        <Button type="primary">Upload data, csvformat</Button>
                        <input style={{ position: 'absolute',cursor:"pointer",opacity: '0',width: '100%',height:'100%',left: '0',}} type="file" accept=".csv" onChange={handleFileUpload} />
                    </label>
                    
                </div>

                <div style={{maxHeight:'670px',overflowY:'auto',marginTop:'24px'}}>
                    <Table rowSelection={rowSelection} dataSource={csvData} columns={columns} rowKey={getKey} />
                </div>
                
            </div>
            <div style={{width:'360px',marginLeft:'24px',border:'1px solid rgb(77 76 76)',padding:'24px',borderRadius:'12px'}}>
                <div style={{textAlign:'center',marginTop:'24px'}}>
                    <Button type="primary"  onClick={calculate}>Calculatefee</Button>
                </div>
                <div style={{
                    textAlign:'center',
                    marginTop:'24px',
                    fontSize:'16px',
                    color:'#929191',
                    wordWrap:'break-word',
                
                }}>
                    {calculateData}
                </div>
            </div>
        </div>
    );
}
export default Home;