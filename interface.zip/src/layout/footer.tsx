import { Footer } from "antd/es/layout/layout";

const footerStyle: React.CSSProperties = {
    textAlign: 'center',
    color: '#fff',
    backgroundColor: '#4096ff',
  };

function Foo() {
    return (
        <Footer style={footerStyle}>Footer</Footer>
    );
}

export default Foo;