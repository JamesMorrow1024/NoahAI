import {   Outlet } from "react-router-dom";

import {  Layout } from 'antd';


import Aside from './aside';
import Foo from "./footer";
import Hed from "./header";
// import { useState } from "react";


const {  Content } = Layout;



const contentStyle: React.CSSProperties = {
  textAlign: 'center',
  // height: '100%',
  lineHeight: '120px',
  color: '#fff',
  backgroundColor: '#0958d9',
};





const layoutStyle = {
  width: '100%',
};
const layoutRightStyle = {
  marginLeft: '200px',
  overflowX: 'hidden',
}

function Lay(){

    return (
    <>
      <Layout style={layoutStyle}>

        <Aside />
        
        <Layout style={layoutRightStyle}>
            <Hed></Hed>
            <Content style={contentStyle}>
                <Outlet />
            </Content>
            <Foo />
        </Layout>
      </Layout>
    </>
       

    );
}
export default Lay;