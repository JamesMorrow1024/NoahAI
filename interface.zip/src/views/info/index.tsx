function Info(){
    return(
        <div>
            <h1>Info</h1>
            <div v-animate={{name:'fade-in-right',loop:true}}  style={{height:'200px',background:'red'}}>ff fasda </div>
            <div style={{height:'350px',background:'blue'}}></div>
            <div style={{height:'350px',background:'green'}}></div>
            <div style={{height:'350px',background:'green'}}></div>
        </div>
    );
}
export default Info;