import { Header } from "antd/es/layout/layout";
import store, { actionsType } from '../redux/index';
import { setGHeight, setGWidth, setMobile } from "../redux/action";
import { trace } from "../utils/tools";

const headerStyle: React.CSSProperties = {
    textAlign: 'center',
    color: '#fff',
    height: 64,
    paddingInline: 48,
    lineHeight: '64px',
    backgroundColor: '#4096ff',
  };


function Hed(){
    
    
    const resizeWindow = ()=>{
        store.dispatch(setGHeight(window.innerWidth));
        store.dispatch(setGHeight(window.innerHeight));
        store.dispatch(setMobile(window.innerWidth<=640));

    }
    window.addEventListener('resize', resizeWindow);
    resizeWindow();

    return(
        <Header style={headerStyle}>Header</Header>
    );
}

export default Hed;