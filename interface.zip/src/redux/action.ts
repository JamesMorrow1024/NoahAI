import { ActionG,actionsType } from "."

export const setGWidth = (value:number):ActionG => {
    return {
        type: actionsType.GWIDTH,
        data: value
    };
}
export const setGHeight = (value:number):ActionG => {
    return {
        type: actionsType.GHEIGHT,
        data: value
    };
}
export const setMobile = (value:boolean):ActionG => {
    return {
        type: actionsType.MOBILE,
        data: value
    };
}
export const setUser = (value:never):ActionG => {
    return {
        type: actionsType.USERINFO,
        data: value
    };
}